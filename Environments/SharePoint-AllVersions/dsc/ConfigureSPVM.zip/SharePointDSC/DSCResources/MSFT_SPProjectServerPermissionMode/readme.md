# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource allows you to set the permissions mode (either SharePoint or
ProjectServer) for a specific project server site.
