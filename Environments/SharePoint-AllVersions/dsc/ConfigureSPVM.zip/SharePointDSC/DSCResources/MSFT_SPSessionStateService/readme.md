# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource will provision a state service app to the local farm. Specify
the name of the database server and database name to provision the app with,
and optionally include the session timeout value. If session timeout is not

The default value for the Ensure parameter is Present. When not specifying this
parameter, the service application is provisioned.
