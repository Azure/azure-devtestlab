# Description

The DnsServerForwarder DSC resource manages the DNS forwarder list of a
Domain Name System (DNS) server. If the parameter `EnableReordering` is set
to `$false` then the preferred forwarder can be put in the series of forwarder
IP addresses.
