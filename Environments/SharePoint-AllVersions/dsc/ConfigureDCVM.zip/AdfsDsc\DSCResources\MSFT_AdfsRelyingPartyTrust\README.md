# Description

The AdfsRelyingPartyTrust DSC resource manages the relying party trusts of the Federation Service.
