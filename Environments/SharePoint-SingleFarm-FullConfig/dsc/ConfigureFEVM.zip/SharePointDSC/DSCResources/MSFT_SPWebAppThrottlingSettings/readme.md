# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is responsible for setting web application settings that are
found under the "resource throttling" screen in central admin. The web
application is specified through the URL property, and then any combination of
settings can be applied. Any settings not included will be left as the default
(or whatever they have been manually changed to within SharePoint). Happy hour
is the setting used to control the window where threshold do not apply
throughout the day. You can specify the start time of this window as well as
