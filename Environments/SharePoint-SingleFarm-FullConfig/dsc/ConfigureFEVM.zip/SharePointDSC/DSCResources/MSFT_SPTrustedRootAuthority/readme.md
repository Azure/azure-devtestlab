# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to create or remove SPTrustedRootAuthority in a
SharePoint farm. It imports the certificate into SharePoint in order for
high trust apps or consuming service applications from other farms will
work.
