# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to manipulate the IRM settings in SharePoint, integrating
it with AD RMS

The default value for the Ensure parameter is Present. When not specifying this
parameter, IRM is configured.
